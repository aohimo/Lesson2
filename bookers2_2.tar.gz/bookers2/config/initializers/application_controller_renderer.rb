# Be sure to restart your server when you modify this file.

# ActiveSupport::Reloader.to_prepare do
#   ApplicationController.renderer.defaults.merge!(
#     http_host: 'example.org',
#     https: false
#   )
# end

Refile.secret_key = '1f27513549c50fce90609f6b51d707a781c983c40e4301d4426cf516ecf8948d442fff849a78f864bf761bf3ea8a1e1201a5e330c0d618ec75caef76babe3a73'