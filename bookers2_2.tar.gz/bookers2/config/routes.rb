Rails.application.routes.draw do
  get 'users/index'
  get 'users/edit'
  devise_for :users
  get 'home/about', to: 'homes#about'
  root to: 'homes#top'
  
  resources :users, only: [:index, :show, :edit, :update]
  resources :books, only: [:create, :index, :show, :destroy, :edit, :update]
  # For details on the DSL available within this file, see http://guides.rubyonrails.org/routing.html
end
